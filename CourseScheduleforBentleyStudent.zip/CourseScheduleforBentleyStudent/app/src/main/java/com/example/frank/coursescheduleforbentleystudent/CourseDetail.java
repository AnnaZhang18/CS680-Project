package com.example.frank.coursescheduleforbentleystudent;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CourseDetail extends AppCompatActivity{

    private TextView course;
    private TextView loc;
    private TextView time;
    private TextView assignment;
    private TextView instructor;
    private Button assignmentbtn;
    String email;
    String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail);
        Button Map = (Button) findViewById(R.id.map);

        Button Dial = (Button) findViewById(R.id.dial);

        Button Emailprof = (Button) findViewById(R.id.emailprof);

        assignmentbtn = (Button) findViewById(R.id.assignment);


        SQLiteDatabase db = LogInActivity.db;
        String Courseid = StudentMenuActivity.course;
        String StudentEmail = LogInActivity.account;
        course = findViewById(R.id.classdetail);
        loc = findViewById(R.id.location);
        time = findViewById(R.id.texttime);
        assignment = findViewById(R.id.assignmentinfo);
        instructor = findViewById(R.id.instructorinfo);
        Cursor cursor = db.rawQuery("SELECT Day,Time,LocationID,CourseID FROM CoursesDetail WHERE CoursesSection=" + "\"" + Courseid + "\"", null);
        cursor.moveToFirst();
        time.setText(time.getText().toString() + cursor.getString(0) + " " + cursor.getString(1));
        loc.setText(loc.getText().toString() + cursor.getString(2));
        cursor = db.rawQuery("SELECT Coursename,TeacherID FROM Courses WHERE CourseID=" + "\"" + cursor.getString(3) + "\"", null);
        cursor.moveToFirst();
        course.setText(Courseid + "     " + cursor.getString(0));
        cursor = db.rawQuery("SELECT Name,TeacherEmail,Phone FROM Teacher WHERE TeacherID=" + "\"" + cursor.getString(1) + "\"", null);
        cursor.moveToFirst();
        instructor.setText(cursor.getString(0) + "\n" + cursor.getString(1)+" "+cursor.getString(2));
        email = cursor.getString(1);
        phone=cursor.getString(2);
        cursor = db.rawQuery("SELECT Note FROM Schedule WHERE CoursesSection=" + "\"" + Courseid +"\" and Email="+ "\"" + StudentEmail +"\"", null);
        cursor.moveToFirst();
        cursor = db.rawQuery("SELECT Assignmentnote FROM Notedetail WHERE Note=" + "\"" + cursor.getString(0) + "\"", null);
        cursor.moveToFirst();
        assignment.setText(cursor.getString(0));
        assignmentbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAssignment();
            }
        });
    }


//    public void onClick(View v) throws SecurityException {
//
//        switch (v.getId()) {
//            case R.id.emailprof:
//                Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
//                i.putExtra(Intent.EXTRA_EMAIL, email);
//                i.setType("message/rfc822");
//                startActivity(i);
//                break;
//            //Implicit intent, call dial
//            case R.id.dial:
//                Uri uri2 = Uri.parse("tel:"+phone);
//                Intent i2 = new Intent(Intent.ACTION_DIAL, uri2);
//                startActivity(i2);
//                break;
//            //Google map
//            case R.id.map:
//                Uri uri3 = Uri.parse("geo:42.386460,-71.221895?z=18");
//                Intent i3 = new Intent(Intent.ACTION_VIEW, uri3);
//                if (i3.resolveActivity(getPackageManager()) != null) {
//                    startActivity(i3);
//                }
//                break;
//            case R.id.assignment:
//                openAssignment();
//                break;
//        }
//    }

    public void openAssignment(){
        Intent i4 = new Intent(this, AssignmentPage.class);
        startActivity(i4);
    }
}
