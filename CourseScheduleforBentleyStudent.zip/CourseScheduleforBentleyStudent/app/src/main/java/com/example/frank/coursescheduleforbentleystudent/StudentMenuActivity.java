package com.example.frank.coursescheduleforbentleystudent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class StudentMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_menu);
    }
}
