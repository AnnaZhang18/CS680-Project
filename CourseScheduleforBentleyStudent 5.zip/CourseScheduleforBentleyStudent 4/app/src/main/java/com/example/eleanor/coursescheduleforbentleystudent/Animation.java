package com.example.eleanor.coursescheduleforbentleystudent;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class Animation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation);
        ImageView img = (ImageView) findViewById(R.id.loading);
        img.setBackgroundResource(R.drawable.animation);

        AnimationRoutine1 task1 = new AnimationRoutine1();

        Timer t = new Timer();
        t.schedule(task1, 1000);


    }

    class AnimationRoutine1 extends TimerTask {

        @Override
        public void run() {
            ImageView img = (ImageView) findViewById(R.id.loading);
            AnimationDrawable frameAnimation = (AnimationDrawable) img.getBackground();
            frameAnimation.start();
        }
    }

}
