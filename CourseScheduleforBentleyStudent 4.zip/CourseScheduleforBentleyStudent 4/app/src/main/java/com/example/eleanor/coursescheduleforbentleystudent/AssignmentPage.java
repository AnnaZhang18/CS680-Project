package com.example.eleanor.coursescheduleforbentleystudent;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AssignmentPage extends AppCompatActivity {
    private ArrayList<String> items;
    private ArrayAdapter<String> itemsAdapter;
    private ListView lvItems;
    private TextToSpeech speaker;
    private int pos;
    private String noteid;
    private int result;
    private NotificationManager mNotificationManager;
    private Notification notifyDetails;
    private int SIMPLE_NOTFICATION_ID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment_page);


		/*
		  Intent notifyIntent = new Intent();
		  notifyIntent.setComponent(new ComponentName("com.course.example",
		                  "com.course.example.IOTest"));
		 */

        //create pending intent to wrap intent so that it
        //will fire when notification selected.

        //build notification object and set parameters



        lvItems = (ListView) findViewById(R.id.lvItems);
        items = new ArrayList<String>();
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        String Courseid = StudentMenuActivity.course;
        String StudentEmail = LogInActivity.account;
        SQLiteDatabase db = LogInActivity.db;
        String date = StudentMenuActivity.date;
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/YYYY");
        final int month = Integer.parseInt(date.trim().substring(0,2));
        final int day = Integer.parseInt(date.trim().substring(3,5));
        Cursor cursor = db.rawQuery("SELECT Note FROM Schedule WHERE CoursesSection=" + "\"" + Courseid +"\" and Email="+ "\"" + StudentEmail +"\"", null);
        cursor.moveToFirst();
        noteid=cursor.getString(0);
        cursor = db.rawQuery("SELECT Assignmentnote FROM Notedetail WHERE Note=" + "\"" + noteid + "\"", null);
        cursor.moveToFirst();
        do {
            int i = 0;
            items.add(i, cursor.getString(0));
            i++;
        } while (cursor.moveToNext());
        itemsAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, items){
            @Override
            public View getView(int position, View convertView, ViewGroup parent){
                String assignment = items.get(position);
                String duedate = assignment.trim().substring(assignment.trim().length()-5);

                int duemonth = Integer.parseInt(duedate.substring(0,2));
                int dueday = Integer.parseInt(duedate.substring(3));

                View v = super.getView(position,convertView,parent);
//                int difference = dueday-day;
                if(duemonth<month || (duemonth==month && dueday<day)) {
                    v.setBackgroundColor(Color.parseColor("#aaaaaa"));
                }
                else if((duemonth==month && dueday>=day) || (duemonth-month==1 && dueday<day)){
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                }
                else{
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                }
                return v;
            }
        };
        lvItems.setAdapter(itemsAdapter);

        // set item click listener
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //get the selected position within array
                pos = position;
                EditText etNewItem = (EditText) findViewById(R.id.etNewItem);
                //show the selected array item in edittext box, allow for edit
                etNewItem.setText(items.get(pos), TextView.BufferType.EDITABLE);
                itemsAdapter.notifyDataSetChanged();
            }
        });
        //set speaker
        speaker=new TextToSpeech(AssignmentPage.this,new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    result = speaker.setLanguage(Locale.US);
                } else {
                    Toast.makeText(getApplicationContext(),"Feature not supported in your device",
                            Toast.LENGTH_SHORT).show();
                }
            }

        });
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public void speak(String output){
        speaker.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        EditText etNewItem = (EditText) findViewById(R.id.etNewItem);
        SQLiteDatabase db = LogInActivity.db;
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.add:
                String itemText = etNewItem.getText().toString();
                itemsAdapter.add(itemText);
                db.execSQL("INSERT INTO Notedetail Values('"+noteid+"','"+itemText+"')");
                speak(itemText+"has been added");
                etNewItem.setText("");
                return true;

//        get the current selected position, and update the string
           // case R.id.update:
             //   items.remove(pos);
               // String oldtext=items.get(pos);
                //String itemText1 = etNewItem.getText().toString();
                //itemsAdapter.insert(itemText1,pos);
                //itemsAdapter.notifyDataSetChanged();
                //db.execSQL("INSERT INTO Notedetail Values('"+noteid+"','"+itemText1+"')");
                //db.delete("Notedetail","Note=? and Assignmentnote=?",new String[]{noteid,oldtext});
                //speak(itemText1+"has been updated");
                //etNewItem.setText("");
                //return true;

//        delete the current selected string from the arraylist
            case R.id.delete:
                items.remove(pos);
                String itemText2= etNewItem.getText().toString();
                db.delete("Notedetail","Note=? and Assignmentnote=?",new String[]{noteid,itemText2});
                speak( etNewItem.getText().toString()+"has been deleted");
                etNewItem.setText("");
                itemsAdapter.notifyDataSetChanged();
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
