package com.example.frank.coursescheduleforbentleystudent;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

/**
 * Created by cindyguo on 4/15/18.
 */

public class Assignment extends AppCompatActivity {
    private ArrayList<String> items;
    private ArrayAdapter<String> itemsAdapter;
    private ListView lvItems;
    private int pos;
    String Courseid = StudentMenuActivity.course;
    String StudentEmail = LogInActivity.account;
    String noteid;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment);
        lvItems = (ListView) findViewById(R.id.lvItems);
        items = new ArrayList<String>();
        itemsAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, items);
        lvItems.setAdapter(itemsAdapter);

        SQLiteDatabase db = LogInActivity.db;
        Cursor cursor = db.rawQuery("SELECT Note FROM Schedule WHERE CoursesSection=" + "\"" + Courseid +"\" and Email="+ "\"" + StudentEmail +"\"", null);
        cursor.moveToFirst();
        noteid=cursor.getString(0);
        cursor = db.rawQuery("SELECT Assignmentnote FROM Notedetail WHERE Note=" + "\"" + noteid + "\"", null);
        if (cursor.moveToFirst()) {
            do {
                int i = 0;
                items.add(i, cursor.getString(0));
                i++;
            } while (cursor.moveToNext());
        }

        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //get the selected position within array
                 pos = position;
                EditText etNewItem = (EditText) findViewById(R.id.etNewItem);
                //show the selected array item in edittext box, allow for edit
                etNewItem.setText(items.get(pos), TextView.BufferType.EDITABLE);
                itemsAdapter.notifyDataSetChanged();
            }
        });

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        EditText etNewItem = (EditText) findViewById(R.id.etNewItem);

        // Handle item selection
        switch (item.getItemId()) {
            case R.id.add:
                String itemText = etNewItem.getText().toString();
                itemsAdapter.add(itemText);
                SQLiteDatabase db = LogInActivity.db;
                db.execSQL("INSERT INTO Notedetail Values('"+noteid+"','"+itemText+"')");
                etNewItem.setText("");
                return true;

            //get the current selected position, and update the string
            case R.id.update:
                items.remove(pos);
                String itemText1 = etNewItem.getText().toString();
                itemsAdapter.insert(pos+1+". "+itemText1,pos);
                SQLiteDatabase db1 = LogInActivity.db;
                db1.execSQL("DELETE FROM Notedetail WHERE Note='"+noteid+"'AND Assignmentnote='"+itemText1+"')");
                db1.execSQL("INSERT INTO Notedetail Values('"+noteid+"','"+itemText1+"')");
                etNewItem.setText("");
                return true;

            //delete the current selected string from the arraylist
            case R.id.delete:
                items.remove(pos);
                String itemText2=items.get(pos);
                //update the list number for the rest of the items
                for(int i=0; i<items.size();i++){
                    items.set(i,i+1+". "+items.get(i));
                }
                itemsAdapter.notifyDataSetChanged();
                SQLiteDatabase db2 = LogInActivity.db;
                db2.execSQL("DELETE FROM Notedetail WHERE Note='"+noteid+"'AND Assignmentnote='"+itemText2+"')");
                etNewItem.setText("");
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
